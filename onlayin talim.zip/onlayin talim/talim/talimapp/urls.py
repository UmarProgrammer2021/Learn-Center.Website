from django.urls import path
from .views import HomePageView,AboutPageView,PricingPageView,CoursesPageView,PortfolioPageView,ContactPageView

urlpatterns =[
    path('', HomePageView.as_view(), name='home'),
    path('haqida', AboutPageView.as_view(), name='haqida'),
    path('kurslar', CoursesPageView.as_view(), name='kurslar'),
    path('aloqa', ContactPageView.as_view(), name='aloqa'),
    path('portfolio', PortfolioPageView.as_view(), name='portfolio'),
    path('narxlar', PricingPageView.as_view(), name='narxlar')
]