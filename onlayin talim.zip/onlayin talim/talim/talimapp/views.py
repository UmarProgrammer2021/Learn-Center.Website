from django.shortcuts import render
from django.views.generic import TemplateView

# Create your views here.

class HomePageView(TemplateView):
    template_name ='index/index.html'
    
class AboutPageView(TemplateView):
    template_name ='about/about.html'
    
class CoursesPageView(TemplateView):
    temple_name = 'courses/courses.html'

class PortfolioPageView(TemplateView):
    temple_name = 'portfolio/portfolio.html'
    
class PricingPageView(TemplateView):
    temple_name = 'pricing/pricing.html'
    
class ContactPageView(TemplateView):
    temple_name = 'contact/contact.html'
    